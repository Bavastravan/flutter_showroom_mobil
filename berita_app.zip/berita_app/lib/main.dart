import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(BeritaApp());
}

class BeritaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Berita App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(),
    );
  }
}
