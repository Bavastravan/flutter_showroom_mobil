import 'package:flutter/material.dart';
import '../models/news_model.dart';

class DetailScreen extends StatelessWidget {
  final News news;

  DetailScreen({required this.news});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(news.title)),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Image.network(news.imageUrl),
            SizedBox(height: 16),
            Text(
              news.content,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
