class News {
  final String title;
  final String summary;
  final String content;
  final String imageUrl;

  News({
    required this.title,
    required this.summary,
    required this.content,
    required this.imageUrl,
  });
}
