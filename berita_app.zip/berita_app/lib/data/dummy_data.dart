import '../models/news_model.dart';

List<News> newsList = [
  News(
    title: "Flutter 3.0 Dirilis!",
    summary: "Flutter 3.0 hadir dengan banyak fitur baru.",
    content: "Flutter 3.0 hadir dengan peningkatan performa, dukungan multiplatform, dan lainnya.",
    imageUrl: "https://flutter.dev/images/flutter-logo-sharing.png",
  ),
  News(
    title: "Tips Membuat UI Responsive",
    summary: "UI responsive penting untuk berbagai ukuran layar.",
    content: "Gunakan LayoutBuilder, MediaQuery, dan widget fleksibel lainnya.",
    imageUrl: "https://miro.medium.com/v2/resize:fit:1200/format:webp/1*7eXJYOPDWBDSZltRynOP_g.png",
  ),
];
