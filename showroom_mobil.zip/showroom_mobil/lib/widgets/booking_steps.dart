import 'package:flutter/material.dart';

class BookingSteps extends StatelessWidget {
  final int currentStep;
  const BookingSteps({super.key, this.currentStep = 0});

  @override
  Widget build(BuildContext context) {
    // ...
    return Row(
      children: [
        // Langkah booking visual jika diperlukan
      ],
    );
  }
}
